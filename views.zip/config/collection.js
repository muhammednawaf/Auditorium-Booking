module.exports = {
    BOOKING_COLLECTION :'booking',
    AUDITORIUM_COLLECTION :'auditorium',
    ADMIN_COLLECTION : 'admin',
    USER_COLLECTION : 'user',
}